# coding=utf-8

import logging
import os
from pathlib import Path
import shutil

from settings import DOC_list, MAX_DOC_COUNT, OUT_DIR, EVAL_ID_DIR_map, TAG_list

logger = logging.getLogger(__name__)


def make_file_list(target_dir, all_file=False):
    if all_file:
        return list(Path(target_dir).glob(f'**/*.*'))

    file_list = []
    for ext in DOC_list:
        _list = list(Path(target_dir).glob(f'**/*.{ext}'))
        file_list += _list
    logger.debug(f"file_list: {len(file_list)}")
    # print(f"file_list: {len(file_list)}")

    for _f in Path(target_dir).glob(f'**/*.*'):
        if _f not in file_list:
            logger.debug(f'{_f} skip!')
            # print(f'{_f} skip!')

    _c = len(file_list)
    if (_c == 0) | (_c > MAX_DOC_COUNT):
        logger.warning(f"ファイル数: {len(file_list)}。間違えてない？ {target_dir}")
        # print(f"ファイル数: {len(file_list)}。間違えてない？")
        file_list = []

    return file_list


def copy_file(from_file, to_directory, tag):
    # 指定ファイルを、指定フォルダのサブディレクトリ(タグの並び。例)AGD/SAG)にコピーする。サブディレクトリが無ければ作る。
    # ファイルがある場合はスキップする。
    dst_directory = os.path.join(to_directory, os.path.join(*tag.split()))
    p = Path(dst_directory)
    if not p.exists():
        p.mkdir(parents=True)

    if p.exists():
        _df = os.path.join(dst_directory, os.path.split(from_file)[-1])
        logger.debug(f"_df: {_df}")
        # print(f"_df: {_df}")
        if Path(_df).exists():
            logger.debug(f"skip: {_df} exist")
            # print(f"skip: {_df} exist")
        else:
            shutil.copy2(from_file, dst_directory)
            logger.debug(f"copy {from_file} to {dst_directory}")
            # print(f"copy {from_file} to {dst_directory}")


def copy_subdir(from_dir, to_dir):
    # 指定フォルダ下の【日付（タグの並び）】フォルダ構成(ファイルを含む)を、指定フォルダ下にコピーする
    # コピー先フォルダが存在する場合はコピーしない。
    sub_dir_list = [os.path.split(_d)[-1] for _d in Path(from_dir).glob('**/202*')]
    # print(f"sub_dir_list: {sub_dir_list}")
    for _s in sub_dir_list:
        _fm = os.path.join(from_dir, _s)
        _to = os.path.join(to_dir, _s)

        if Path(_fm).exists():
            if not Path(_to).exists():
                shutil.copytree(
                    os.path.join(from_dir, _s),
                    os.path.join(to_dir, _s))
            else:
                logger.debug(f"_to: {_to} exist!")
                # print(f"_to: {_to} exist!")
        else:
            logger.debug(f"_fm: {_fm} not exist!")
            # print(f"_fm: {_fm} not exist!")


def delete_file2():
    # 【20E401(C7100),20E402(B7100)】フォルダを削除する
    for eid in EVAL_ID_DIR_map.keys():
        _fm = os.path.join(OUT_DIR, eid)
        if not Path(_fm).exists():
            continue

        shutil.rmtree(_fm)


def copy_file2():
    # 【日付（タグの並び）】フォルダを対応するフォルダにコピーする
    for eid in EVAL_ID_DIR_map.keys():
        _fm = os.path.join(OUT_DIR, eid)
        _to = EVAL_ID_DIR_map[eid]
        if not Path(_fm).exists():
            continue
        copy_subdir(_fm, _to)
        logger.debug(f"copy_subdir {_fm} {_to}")
        # print(f"copy_subdir {_fm} {_to}")

    # 20E401(C7100)下の【日付（タグの並び）】
    # 　AGD¥SAG\Nextwave_Platform_SAG.pdf
    # ファイルパス求め、
    # 20E401(C7100)下の【日付（タグの並び）】まで削り
    # 以下に連結し、コピーする。
    tag_dir_map = {}
    for _k, _v in TAG_list.items():
        tag_dir_map.setdefault(_v.split()[-1], _v)
    # print(f"tag_dir_map: {tag_dir_map}")

    for eid in EVAL_ID_DIR_map.keys():
        _fm = os.path.join(OUT_DIR, eid)
        _to = os.path.join(EVAL_ID_DIR_map[eid], "最新版")
        # print(f"_fm: {_fm}")
        # print(f"_to: {_to}")
        if not Path(_fm).exists():
            continue

        for _f in Path(_fm).glob("**/*.*"):
            _name = os.path.split(_f)[-1]
            _path = os.path.split(_f)[0]
            _mp = tag_dir_map[os.path.split(_path)[-1]].split()
            _td = os.path.join(_to, *_mp) #, _name)

            if not Path(_td).exists():
                Path(_td).mkdir(parents=True)

            if not Path(_td).exists():
                logger.error(f"{_td} 作成失敗")
                # print(f"{_td} 作成失敗")
                continue

            if Path(os.path.join(_td, _name)).exists():
                logger.debug(f"{os.path.join(_td, _name)} 存在するのでコピースキップ")
                # print(f"{os.path.join(_td, _name)} 存在するのでコピースキップ")
                continue

            logger.debug(f"copy2 {_f} {_td}")
            # print(f"copy2 {_f} {_td}")
            shutil.copy2(_f, _td)


def delete_file(file_path):
    _p = Path(file_path)
    if _p.exists():
        _p.unlink()


def is_target(file_path):
    file_ext = os.path.splitext(file_path)[-1]
    print(f"file_ext: {file_ext} file_path: {file_path}")
    if file_ext[file_ext.find(".")+1:] in DOC_list:
        return True
    else:
        return False
