import os

import tkinter as tk
from tkinter import ttk
import tkinter.filedialog

from tkcalendar import DateEntry

from settings import EVAL_ID_list, TAG_KEY_list, TAG_list, OUT_DIR
from tool import make_file_list, copy_file, is_target


class EvidenceWidget:
    def __init__(self, file_info_list, root, target_dir=OUT_DIR):
        self.file_info_list = file_info_list
        self.root = root
        # self.target_dir = target_dir    # コピー先ディレクトリ
        self.target_dir = target_dir    # コピー先ディレクトリ
        self._frame = []
        self.is_target = {"cb" : [], "cb_val" : []}
        self.file_mame = {"lb" : [], }
        self.eval_id = {
            "module" : EVAL_ID_list,
            "cb": [],
            "cb_val": []
        }
        self._date = {
            "cal":[],
            "cal_var":[]
        }
        self._tag = {
            "module": TAG_KEY_list,
            "cb": [],
            "cb_val": []
        }

        _cnt = len(file_info_list)
        for i in range(_cnt):
            self.add_frame(self.root, i)
            # 対象か
            self.add_target(self._frame[-1], i)
            self.add_file_mame(self._frame[-1], i)
            self.add_eval_id(self._frame[-1], i)
            self.add_date(self._frame[-1], i)
            self.add_tag(self._frame[-1],  i)

        self.add_frame(self.root, _cnt)

        self.out_bt = ttk.Button(self._frame[-1], text="出力する", width=10,
                        command=lambda :self.arrange())
        self.out_bt.grid(row=0, column=0)

        self.to_dir = tk.StringVar(value=f"--> {self.target_dir}")
        # self.to_dir = tk.StringVar(value=f"--> {OUT_DIR}")
        # self.to_dir.set(f"--> {self.target_dir}")
        bt = ttk.Button(self._frame[-1], textvariable=self.to_dir,
                        command=self.select_dir, width=80)
        bt.grid(row=0, column=1)

    def select_dir(self):
        ini_dir = self.target_dir
        ret = tkinter.filedialog.askdirectory(initialdir=ini_dir, title='出力ディレクトリ選択', mustexist = True)
        if ret:
            self.target_dir = ret
            self.to_dir.set(f"--> {self.target_dir}")

        # print(ret)

    def add_frame(self, root,  i):
        self._frame.append("")
        self._frame[-1] = tk.Frame(root, width=600, height=50, bg="coral" if (i % 2) == 0 else "blue")
        self._frame[-1].grid()

    def add_target(self, flame, i):
        self.is_target["cb"].append("")
        if is_target(self.file_info_list[i]["file_path"]):
            self.is_target["cb_val"].append(tk.IntVar(value=1))
        else:
            self.is_target["cb_val"].append(tk.IntVar(value=0))
        # self.is_target["cb_val"].append(tk.IntVar(value=1))
        self.is_target["cb"][-1] = ttk.Checkbutton(flame,
                                              padding=(5),
                                              text="", variable=self.is_target["cb_val"][-1])
        self.is_target["cb"][-1].grid(row=0, column=0)

    def add_file_mame(self, flame, i):
        self.file_mame["lb"].append("")
        file_name = os.path.split(self.file_info_list[i]["file_path"])[-1]
        self.file_mame["lb"][-1] = ttk.Label(flame, width=64,
                                        text=file_name,
                                        anchor="w")
        self.file_mame["lb"][-1].grid(row=0, column=1)

    def add_eval_id(self, flame, i):
        self.eval_id["cb"].append("")
        self.eval_id["cb_val"].append(tk.StringVar())
        self.eval_id["cb_val"][-1].set(self.file_info_list[i]["eval_id"])
        self.eval_id["cb"][-1] = ttk.Combobox(flame, height=7, values=self.eval_id["module"], width=16,
                                         textvariable=self.eval_id["cb_val"][-1], state="readonly")
        self.eval_id["cb"][-1].grid(row=0, column=2)

    def add_date(self, flame, i):
        self._date["cal"].append("")
        self._date["cal_var"].append(tk.StringVar())

        year = int(self.file_info_list[i]["_date"][:4])
        month = int(self.file_info_list[i]["_date"][5:7])
        day = int(self.file_info_list[i]["_date"][-2:])

        self._date["cal"][-1] = DateEntry(flame, width=10, bg="darkblue", fg="white",
                                          textvariable=self._date["cal_var"][-1] ,
                                     year=year, month=month, day=day, locale="ja_JP")
        self._date["cal"][-1].grid(row=0, column=3)

    def add_tag(self,flame, i):
        self._tag["cb"].append("")
        self._tag["cb_val"].append(tk.StringVar())
        self._tag["cb_val"][-1].set(self.file_info_list[i]["_tag"])
        self._tag["cb"][-1] = ttk.Combobox(flame, height=7, values=self._tag["module"], width=16,
                                      textvariable=self._tag["cb_val"][-1], state="readonly")
        self._tag["cb"][-1].grid(row=0, column=4)

    def show(self):
        for i, v in enumerate(self.is_target["cb_val"]):
            if v.get()==1:
                file_name = os.path.split(self.file_info_list[i]["file_path"])[-1]
                print(f'{file_name} '
                      f'{self.eval_id["cb_val"][i].get()} '
                      f'{self._date["cal_var"][i].get()} {self._tag["cb_val"][i].get()}')

    def arrange(self):
        res = {}

        for i, v in enumerate(self.is_target["cb_val"]):
            if v.get()==0:
                continue

            file_path = self.file_info_list[i]["file_path"]
            eval_id = self.eval_id["cb_val"][i].get()
            _date = self._date["cal_var"][i].get()
            _tag = self._tag["cb_val"][i].get()

            res.setdefault(eval_id, {})
            res[eval_id].setdefault(_date, {})
            res[eval_id][_date].setdefault(_tag, [])
            res[eval_id][_date][_tag].append(file_path)

        for eval_id, _v in res.items():
            # print(eval_id)
            for _date, _v2 in _v.items():
                # print(f"    {_date}")
                merged_tag = " ".join(set([TAG_list[k].split()[-1] for k in res[eval_id][_date].keys()]))
                for _tag, file_list in _v2.items():
                    # print(f"        {_tag}")
                    for f in file_list:
                        # print(f"            {f} => {os.path.split(f)[0]}\\{eval_id}\\{_date.replace('/','')}（{merged_tag}）")
                        # print(os.path.join(os.path.split(f)[0], eval_id, f"{_date.replace('/','')}（{merged_tag}）"))
                        copy_file(f,
                                  # os.path.join(os.path.split(f)[0], eval_id, f"{_date.replace('/','')}（{merged_tag}）"),
                                  os.path.join(self.target_dir, eval_id, f"{_date.replace('/','')}（{merged_tag}）"),
                                  TAG_list[_tag])

        self.root.destroy()


def main(file_info_list, target_dir):
    root = tk.Tk()
    root.title(f"【{target_dir}】のドキュメント")
    root.geometry("740x400")
    # f = tkinter.filedialog.Open()

    EvidenceWidget(file_info_list, root)

    root.mainloop()


def main2():
    # カレントフォルダ配下のフォルダについて、複数ファイルがある場合、列挙する
    root = tk.Tk()
    root.title("DocMan")
    root.geometry("740x400")

    UptodateWidget(root)

    root.mainloop()


if __name__ == '__main__':
    file_info_list1 = [
        {
            'file_path': 'C7100_GM.pdf',
            'eval_id': '20E401(C7100)',
            '_date': '2021/07/05',
            '_tag':  'SSG',
        },
        {
            'file_path': 'B7100_GM.pdf',
            'eval_id': '20E402(B7100)',
            '_date': '2021/07/04',
            '_tag':  'SAG',
        },
        {
            'file_path': 'C7100_Key_Management.V1.0.0.docx',
            'eval_id': '20E402(C7100)',
            '_date': '2021/07/04',
            '_tag': 'KMD',
        },
        {
            'file_path': 'B7100_Entry_Document.GM.pdf',
            'eval_id': '20E402(B7100)',
            '_date': '2021/07/04',
            '_tag': 'ED',
        },
    ]
    main(file_info_list1)
