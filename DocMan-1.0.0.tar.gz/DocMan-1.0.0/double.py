# coding=utf-8

import logging

from all import main


logger = logging.getLogger(__name__)

logger.setLevel(logging.DEBUG)


if __name__ == '__main__':
    logger.info("start")

    main(r"K:\07 証拠資料\最新版")
    main(r"L:\07 証拠資料\最新版")

    logger.info("end")
