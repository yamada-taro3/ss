from setuptools import setup

setup(
    name='DocMan',
    version='1.0.0',
    packages=[''],
    url='https://github.com/yamada-taro3',
    license='',
    author='m-shi',
    author_email='m-shinohara',
    description='test'
)
