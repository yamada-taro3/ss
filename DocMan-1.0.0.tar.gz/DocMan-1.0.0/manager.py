import datetime
import difflib
import os

import fire

from settings import IN_DIR, EVAL_ID_list, TAG_KEY_list
from tool import make_file_list
import gui as myg


def get_max(target_string, compare_string_list):
    max_ratio = -1
    matched_string = ""
    # print(target_string)
    for _string in compare_string_list:
        ratio = difflib.SequenceMatcher(None, target_string, _string).ratio()
        # print(f"{target_string} {ratio} {_string}")
        if ratio == max_ratio:
            # print("same")
            pass
        if ratio > max_ratio:
            max_ratio = ratio
            matched_string = _string

    return matched_string


def guess_file(file_path):
    target_file_name = os.path.split(file_path)[-1]
    today = datetime.datetime.now().strftime("%Y/%m/%d")
    # EVAL_ID
    eval_id = get_max(target_file_name, EVAL_ID_list)

    # DATE
    _date = today

    # TAG
    # _tag = TAG_list[get_max(target_file_name, TAG_KEY_list)]
    _tag = get_max(target_file_name, TAG_KEY_list)

    res = {
        'file_path': file_path,
        # 'file_path': target_file_name,
        'eval_id': eval_id,
        '_date': _date,
        '_tag':  _tag,
    }
    # print(res)
    return res


def main(target_dir=IN_DIR, all_file=True):
    if target_dir:
        file_info_list = []

        file_list = make_file_list(target_dir, all_file)
        for file_path in file_list:
            file_info_list.append(guess_file(file_path))

            # for _info in file_info_list:
            #     print(f'{os.path.split(_info["file_path"])[-1]:<64} {_info["eval_id"]} {_info["_date"]} {_info["_tag"].split()[-1]}')

        if file_info_list:
            myg.main(file_info_list, target_dir)


if __name__ == '__main__':
    fire.Fire(main)
    # main(target_dir=r'C:\Users\m-shi\Downloads\最新版')