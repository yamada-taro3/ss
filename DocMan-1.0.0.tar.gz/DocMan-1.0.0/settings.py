###############
# Manager関連
# 外部PCで使用する
###############
# 証拠資料の入力フォルダ
IN_DIR = r"C:\Users\m-shi\Downloads\in"

# 証拠資料の出力フォルダ
OUT_DIR = r"E:\07 証拠資料"

# 入力ファイルの制限数
MAX_DOC_COUNT = 20


###############
# Manager関連
# 内部PCで使用する
###############
# 評価IDと証拠資料格納ディレクトリの対応
EVAL_ID_DIR_map = {
    "20E401(C7100)": r"K:\07 証拠資料",
    "20E402(B7100)": r"L:\07 証拠資料"
}

EVAL_ID_list = ['20E401(C7100)', '20E402(B7100)']

TAG_KEY_list = ['セキュリティターゲット', 'SSG', 'SAG', 'UserGuide', 'Entropy_Document', 'Key_Management_Description']

TAG_list = {'SSG': 'AGD SSG',
            'SAG': 'AGD SAG',
            'UserGuide': 'AGD UG',
            'Entropy_Document': 'ED',
            'Key_Management_Description': 'KMD',
            'セキュリティターゲット': 'ST',
            }

DOC_list = {
    'docx',
    'pdf',
    # 'xlsx',
}
