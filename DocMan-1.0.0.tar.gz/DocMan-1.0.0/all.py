# coding=utf-8

import logging
import os
import tkinter as tk
from tkinter import ttk

from tool import copy_file2, delete_file2, make_file_list, delete_file
import tool

LOG_FILE = 'all.log'

_logfile_formatting = " ".join([
    '%(asctime)s',
    '%(levelname)-8s',
    '[%(module)s#%(funcName)s',
    '%(lineno)d]',
    '%(message)s'])

_console_formatting = " ".join([
    '%(asctime)s',
    '[%(levelname)-8s]',
    # '[%(module)s#%(funcName)s',
    # '%(lineno)d]',
    '%(message)s'])

logger = logging.getLogger(__name__)

# ログファイル
fh = logging.FileHandler(LOG_FILE)
fh.setLevel(logging.DEBUG)
fh.setFormatter(logging.Formatter(_logfile_formatting))

# コンソール
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(logging.Formatter(_console_formatting))

logger.setLevel(logging.DEBUG)
tool.logger.setLevel(logging.DEBUG)

logger.addHandler(ch)
tool.logger.addHandler(ch)
logger.addHandler(fh)
tool.logger.addHandler(fh)


class UptodateWidget:
    def __init__(self, root, target_dir="."):
        self.root = root
        self._frame = []
        self.is_target = {"cb": [], "cb_val": [], "file_name": [], "_tag": []}
        self.file_mame = {"lb": [], }
        self._tag = {"lb": [], }
        self.file_list = make_file_list(target_dir)

        _d = {}
        self._d = {}
        for file_path in self.file_list:
            _path = os.path.split(file_path)[0]
            _name = os.path.split(file_path)[-1]
            _d.setdefault(_path, [])
            _d[_path].append(_name)
        # self.file_dict = _d
        for _key, _val in _d.items():
            if len(_val) > 1:
                self._d.setdefault(_key, _val)

        _toggle = 0
        for _key, _val in self._d.items():
            _bg = "coral" if (_toggle % 2) == 0 else "blue"
            self.add_frame(self.root, len(_val), _bg)
            _toggle += 1
            self.add_tag(self._frame[-1], 0, _key, len(_val))

            for _i, _file in enumerate(_val):
                self.add_target(self._frame[-1], _i, _file, _key)
                self.add_file_mame(self._frame[-1], _i, _file)

        self.add_frame(self.root, 1, "red")

        bt = ttk.Button(self._frame[-1], text="選択ファイルを削除する",
                        # width=10,
                        command=lambda: self.delete())
        bt.grid(row=0, column=0)

    def add_frame(self, root,  cnt, bg):
        self._frame.append("")
        self._frame[-1] = tk.Frame(root, width=600, height=40*cnt, bg=bg)
        self._frame[-1].grid()

    def add_target(self, frame, i, file_name, _tag):
        self.is_target["cb"].append("")
        self.is_target["file_name"].append("")
        self.is_target["file_name"][-1] = file_name
        self.is_target["_tag"].append("")
        self.is_target["_tag"][-1] = _tag
        self.is_target["cb_val"].append(tk.IntVar(value=0))
        self.is_target["cb"][-1] = ttk.Checkbutton(frame,
                                              padding=(5),
                                              text="", variable=self.is_target["cb_val"][-1])
        self.is_target["cb"][-1].grid(row=i, column=0)
        # self.is_target["cb_val"][-1].set(1)

        logger.debug(f'{self.is_target["_tag"][-1]} {self.is_target["file_name"][-1]}')
        #print(f'{self.is_target["_tag"][-1]} {self.is_target["file_name"][-1]}')

    def add_file_mame(self, frame, i, file_name):
        self.file_mame["lb"].append("")
        self.file_mame["lb"][-1] = ttk.Label(frame, width=64,
                                        text=file_name,
                                        anchor="w")
        self.file_mame["lb"][-1].grid(row=i, column=1)

    def add_tag(self, frame, i, tag_name, cnt):
        self._tag["lb"].append("")
        self._tag["lb"][-1] = ttk.Label(frame, width=48,
                                        text=tag_name,
                                        anchor="w")
        self._tag["lb"][-1].grid(row=i, column=2, rowspan=cnt)

    def delete(self):
        for _i, _v in enumerate(self.is_target["cb_val"]):
            logger.debug(f"_v: {_v.get()}")
            # print(f"_v: {_v.get()}")
            if _v.get() == 1:
                _f = os.path.join(self.is_target["_tag"][_i], self.is_target["file_name"][_i])
                delete_file(_f)
                logger.debug(f'delete {_f}')
                # print(f'delete {_f}')

        self.root.destroy()


def is_double(target_dir):
    file_list = make_file_list(target_dir)

    _d = {}
    for file_path in file_list:
        _path = os.path.split(file_path)[0]
        _name = os.path.split(file_path)[-1]
        _d.setdefault(_path, [])
        _d[_path].append(_name)

    for _key, _val in _d.items():
        if len(_val) > 1:
            return True
    else:
        return False


def main(target_dir):
    # カレントフォルダ配下のフォルダについて、複数ファイルがある場合、列挙する
    if is_double(target_dir):
        root = tk.Tk()
        root.title(f"【{target_dir}】最新版の整理")
        root.geometry("740x400")

        UptodateWidget(root, target_dir)

        root.mainloop()
    else:
        logger.info(f"skip double check {target_dir}")


if __name__ == '__main__':
    logger.info("start")
    copy_file2()

    main(r"K:\07 証拠資料\最新版")
    main(r"L:\07 証拠資料\最新版")

    delete_file2()
    logger.info("end")
