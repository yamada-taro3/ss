# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import datetime
import difflib
import os
from pathlib import Path

import fire

EVAL_ID_list = ['20E401(C7100)', '20E402(B7100)']
TAG_KEY_list = ['セキュリティターゲット', 'SSG', 'SAG', 'UG', 'ED', 'KMD']
TAG_list = {'SSG': 'AGD SSG',
            'SAG': 'AGD SAG',
            'UG': 'AGD UG',
            'ED': 'ED',
            'KMD': 'KMD',
            'セキュリティターゲット': 'ST',
            }
merged_file_info = {}


def numbering_new_list(org_list):
    return [f'{i+1}.{item}' for i, item in enumerate(org_list)]


def get_max(target_string, compare_string_list):
    max_ratio = -1
    matched_string = ""
    # print(target_string)
    for _string in compare_string_list:
        ratio = difflib.SequenceMatcher(None, target_string, _string).ratio()
        # print(f"{target_string} {ratio} {_string}")
        if ratio == max_ratio:
            # print("same")
            pass
        if ratio > max_ratio:
            max_ratio = ratio
            matched_string = _string

    return matched_string


def guess_file(file_path):
    target_file_name = os.path.split(file_path)[-1]
    today = datetime.datetime.now().strftime("%Y%m%d")
    # EVAL_ID
    eval_id = get_max(target_file_name, EVAL_ID_list)

    # DATE
    _date = today

    # TAG
    _tag = TAG_list[get_max(target_file_name, TAG_KEY_list)]

    res = {
        # 'file_path': file_path,
        'file_path': target_file_name,
        'eval_id': eval_id,
        '_date': _date,
        '_tag':  _tag,
    }
    # print(res)
    return res


def main(target_dir="", target_file=""):
    if target_dir:
        file_info_list = []

        file_list = make_file_list(target_dir)
        for file_path in file_list:
            file_info_list.append(guess_file(file_path))

        for _info in file_info_list:
            print(f'{_info["file_path"]:<64} {_info["eval_id"]} {_info["_date"]} {_info["_tag"].split()[-1]}')


class QueryMan:
    def __init__(self):
        self.step_list = []

    def add_step(self, numbering_menu_list, pre_string, prompt_string, retry_menu_flag=True):
        self.step_list.append(
            {
                "numbering_menu_list": numbering_menu_list,
                "pre_string": pre_string,
                "prompt_string": prompt_string,
                "string_menu_list": ['r.Step1からやり直す', 'a.中止'] if retry_menu_flag else []
            }
        )
        return len(self.step_list)

    # def pop_step(self, step_id):
    #     return self.step_list.pop(step_id-1)

    def query(self, step_id):
        total = len(self.step_list)
        if step_id > total | step_id < 1:
            print(f"step_id > total: {step_id} > {total}")
            return ""

        n_menu_item = self.step_list[step_id-1]["numbering_menu_list"]
        target_file_name = self.step_list[step_id-1]["pre_string"]
        prompt = self.step_list[step_id-1]["prompt_string"]
        s_menu_item = self.step_list[step_id-1]["string_menu_list"]

        while True:
            # 入力値が範囲外の場合は問い合わせを繰り返す。
            if total > 1:
                print(f'Step {step_id}/{total} {target_file_name}')
            else:
                print(f'{target_file_name}')
            choice = ' / '.join(numbering_new_list(n_menu_item)+s_menu_item)
            var = input(f"{prompt}？ ({choice}) : ")

            is_valid = False
            if s_menu_item:
                if is_string_range(var, s_menu_item) | is_numeric_range(var, n_menu_item):
                    is_valid = True
            else:
                if is_numeric_range(var, n_menu_item):
                    is_valid = True

            if is_valid:
                break

        return var


def is_string_range(var, s_menu_item):
    # varがs_menu_itemに該当するか
    for s in s_menu_item:
        if var.lower() == s.split('.')[0]:
            return True
    else:
        return False


def is_numeric_range(var, n_menu_item):
    # varがn_menu_itemに該当するか
    for i, n in enumerate(n_menu_item):
        if var == str(i+1):
            return True
    else:
        return False


def add_file(target_file):
    add_file_info = {
        'file_path': '',
        'eval_id': '',
        '_date': '',
        '_tag': '',
    }

    target_file_name = os.path.split(target_file)[-1]
    today = datetime.datetime.now().strftime("%Y%m%d")

    qm = QueryMan()
    q1 = qm.add_step(['Yes', 'No'], target_file_name, '対象か', retry_menu_flag=False)
    var = qm.query(q1)
    if var == '2':
        print("exit add_file2")
        return add_file_info

    target_file_path = target_file

    qm = QueryMan()
    q1 = qm.add_step(EVAL_ID_list, target_file_name, '評価ID')
    q2 = qm.add_step([today, "その他"], target_file_name, '日付')
    q3 = qm.add_step(TAG_KEY_list, target_file_name, 'タグ')

    while True:
        var = qm.query(q1)
        if var.lower() == 'r':
            continue
        elif var.lower() == 'a':
            break
        else:
            # 入力誤りがあった場合はここで例外発生するのでチェックしない
            target_eval_id = EVAL_ID_list[int(var)-1]

        var = qm.query(q2)
        if var.lower() == 'r':
            continue
        elif var.lower() == 'a':
            break
        elif var == '1':
            # add_file_info['_date'] = today
            target_date = today
        else:
            var = input(f'日付入力? (例.20210713) : ')
            # add_file_info['_date'] = var
            target_date = var

        var = qm.query(q3)
        if var.lower() == 'r':
            continue
        elif var.lower() == 'a':
            break
        else:
            # add_file_info['_tag'] = TAG_list[TAG_KEY_list[int(var) - 1]]
            target_tag = TAG_list[TAG_KEY_list[int(var) - 1]]

        add_file_info['file_path'] = target_file_path
        add_file_info['eval_id'] = target_eval_id
        add_file_info['_date'] = target_date
        add_file_info['_tag'] = target_tag

        break

    print("exit add_file2")
    return add_file_info


def add_file2(target_file):
    add_file_info = {
        'file_path': '',
        'eval_id': '',
        '_date': '',
        '_tag': '',
    }

    target_file_name = os.path.split(target_file)[-1]
    today = datetime.datetime.now().strftime("%Y%m%d")
    while True:
        print(f'Step 1/4 {target_file_name}')
        choice = ' / '.join(numbering_new_list(['Yes', 'No']))
        var = input(f"対象か？ ({choice}) : ")

        if var == '1':
            target_file_path = target_file
            # add_file_info['file_path'] = target_file
        elif var == '2':
            break
        else:
            continue

        print(f'Step 2/4 {target_file_name}')
        choice = ' / '.join(numbering_new_list(EVAL_ID_list) + ['r.Step1からやり直す', 'a.中止'])
        var = input(f'評価ID？ ({choice}) : ')

        if var.lower() == 'r':
            continue
        elif var.lower() == 'a':
            break
        else:
            # 入力誤りがあった場合はここで例外発生するのでチェックしない
            target_eval_id = EVAL_ID_list[int(var)-1]
            # add_file_info['eval_id'] = EVAL_ID_list[int(var)-1]

        print(f'Step 3/4 {target_file_name}')
        choice = ' / '.join(numbering_new_list([today, "その他"]) + ['r.Step1からやり直す', 'a.中止'])
        var = input(f'日付？ ({choice}) : ')
        if var.lower() == 'r':
            continue
        elif var.lower() == 'a':
            break
        elif var == '1':
            # add_file_info['_date'] = today
            target_date = today
        else:
            var = input(f'日付入力? (例.20210713) : ')
            # add_file_info['_date'] = var
            target_date = var

        print(f'Step 4/4 {target_file_name}')
        choice = ' / '.join(numbering_new_list(TAG_KEY_list) + ['r.Step1からやり直す', 'a.中止'])
        var = input(f'タグ？ ({choice}) : ')
        if var.lower() == 'r':
            continue
        elif var.lower() == 'a':
            break
        else:
            # add_file_info['_tag'] = TAG_list[TAG_KEY_list[int(var) - 1]]
            target_tag = TAG_list[TAG_KEY_list[int(var) - 1]]

        add_file_info['file_path'] = target_file_path
        add_file_info['eval_id'] = target_eval_id
        add_file_info['_date'] = target_date
        add_file_info['_tag'] = target_tag

        #
        #
        #
        # eval_id = add_file_info['eval_id']
        # _date = add_file_info['_date']
        #
        # print("add_file_info")
        # merged_file_info.setdefault(eval_id, {})
        # merged_file_info[eval_id].setdefault(_date, [])
        # merged_file_info[eval_id][_date].append((add_file_info['file_path'], add_file_info['_tag']))

        break
    # {'20E401(C7100)':
    #      {'20210630':
    #           [('Nextwave_Platform_SAG.pdf', 'ST'),
    #            ('VersaLinkC71XX_MultifunctionPrinter_UserGuide_22Apr21.pdf', 'AGD UG')]},
    #  '20E402(B7100)':
    #      {'20210630':
    #           [('VersaLinkB71XX_MultifunctionPrinter_UserGuide_22Apr21.pdf', 'AGD UG')]}
    #           }

    print("exit add_file")
    return add_file_info


def make_file_list(target_dir):
    #
    file_list = list(Path(target_dir).glob('**/*.*'))
    return file_list


def main2(target_dir="", target_file=""):
    # print(f'target_dir:{target_dir}')
    # print(f'target_file:{target_file}')

    if target_dir:
        # ファイルリストを作成
        file_list = make_file_list(target_dir)

        # ファイル処理
        for file_path in file_list:
            # file_info.append(add_file(file_path))
            marge(add_file(file_path))

    if target_file:
        # ファイル処理
        # file_info.append(add_file(file_path))
        marge(add_file(target_file))

    # merged_file_infoの処理
    # 日付（タグ、・・・）
    #   AGD
    #    SAG
    if merged_file_info:
        for eval_id in merged_file_info.keys():
            print(f"{eval_id}")
            for _date in merged_file_info[eval_id].keys():
                print(f"  {_date}")
                for info in merged_file_info[eval_id][_date]:
                    print(f"    {os.path.split(info[0])[-1]} {info[1]}")


def marge(add_file_info):
    if add_file_info:
        eval_id = add_file_info['eval_id']
        _date = add_file_info['_date']

        merged_file_info.setdefault(eval_id, {})
        merged_file_info[eval_id].setdefault(_date, [])
        merged_file_info[eval_id][_date].append((add_file_info['file_path'], add_file_info['_tag']))


# def marge_file_info(file_info):
#     # ファイル名が入っているものを対象に
#     # 評価ID毎に分ける
#     # さらに日付毎に分ける
#     if file_info['file_path']
#
#     {
#         "20E401(C7100)": {
#             "20210630": (
#                 ("Nextwave_Platform_SAG.pdf", "AGD SAG"),
#                 ("VersaLinkC71XX_MultifunctionPrinter_UserGuide_22Apr21.pdf", "AGD UG"),
#             )
#         }
#     }


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    fire.Fire(main)
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
